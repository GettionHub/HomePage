﻿<?php
/**
 * vCard
 *
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>

    <main class="main">
	    <div class="container gutter-top">
		    <div class="row sticky-parent">
			    <!-- Sidebar -->
                <?php $this->need('aside.php'); ?>
		        
				<!-- Content -->
		        <div class="col-12 col-md-12 col-xl-9">
				    <div class="box pb-0">
					    <!-- Menu -->
					    <?php $this->need('menu.php'); ?>
					    <!-- About -->
						<div class="pb-0 pb-sm-2">
		                    <h1 class="title title--h1 title__separate">关于我们</h1>
						    <?php $this->options->sabout(); ?>
					    </div>
						
						<!-- What -->
						<div class="box-inner pb-0">
						    <h2 class="title title--h3">我可以做什么</h2>
							<div class="row">
							    <!-- Case Item -->
							    <div class="col-12 col-lg-6">
							        <div class="case-item box box__second">
									    <img class="case-item__icon" src="<?php $this->options->themeUrl('assets/icons/icon-design.svg'); ?>" alt="" />
										<div>
									        <h3 class="title title--h5">Web Design</h3>
										    <p class="case-item__caption">The most modern and high-quality design made at a professional level.</p>
										</div>	
									</div>
								</div>
								
								<!-- Case Item -->
								<div class="col-12 col-lg-6">
							        <div class="case-item box box__second">
									    <img class="case-item__icon" src="<?php $this->options->themeUrl('assets/icons/icon-dev.svg'); ?>" alt="" />
										<div>
									        <h3 class="title title--h5">Web Development</h3>
										    <p class="case-item__caption">High-quality and professional development of sites at the professional level.</p>
										</div>
									</div>
								</div>
								
								<!-- Case Item -->
								<div class="col-12 col-lg-6">
								    <div class="case-item box box__second">
								        <img class="case-item__icon" src="<?php $this->options->themeUrl('assets/icons/icon-app.svg'); ?>" alt="" />
										<div>
								            <h3 class="title title--h5">Mobile Apps</h3>
									        <p class="case-item__caption">Professional development of applications for iOS and Android.</p>
										</div>
								   </div>
								</div>
								
								<!-- Case Item -->
								<div class="col-12 col-lg-6">
								    <div class="case-item box box__second">
									    <img class="case-item__icon" src="<?php $this->options->themeUrl('assets/icons/icon-photo.svg'); ?>" alt="" />
										<div>
									        <h3 class="title title--h5">Photography</h3>
										    <p class="case-item__caption">I make high-quality photos of any category at a professional level.</p>
										</div>
									</div>
								</div>
							</div>	
						</div>
						
						


						<?php $this->need('portfolio.php'); ?>


						<!-- Testimonials -->
						<div class="box-inner box-inner--white">
						    <h2 class="title title--h3">最新回复</h2>
						
						    <div class="swiper-container js-carousel-review">
                                <div class="swiper-wrapper">

								    <?php $this->widget('Widget_Comments_Recent','ignoreAuthor=false&pageSize=8')->to($comments); ?>
									<?php while($comments->next()): ?>  
								    <!-- Item review -->
                                    <div class="swiper-slide review-item">
										<svg class="avatar avatar--80" viewBox="0 0 84 84">
                                            <g class="avatar__hexagon">
                                                <image xlink:href="<?php $email=$comments->mail; $imgUrl = getGravatar($email);echo ''.$imgUrl.''; ?>" height="100%" width="100%" />
                                            </g>
                                        </svg>
									    <h4 class="title title--h5"><?php $comments->author(); ?><?php if ($comments->authorId !=0): ?><?php endif; ?></h4>
										<p class="review-item__caption"><?php $comments->excerpt(25, '...'); ?></p>
									</div>
									<?php endwhile; ?>
									
									
                                </div>
    
                                <div class="swiper-pagination"></div>
                            </div>
						</div>
						

					</div>
					
					<!-- Footer -->
					<footer class="footer"><?php if($this->options->footnav){$this->options->footnav();} ?></footer>
		        </div>
			</div>
		</div>	
    </main>

    <?php $this->need('footer.php'); ?>
